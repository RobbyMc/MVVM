package com.example.mvvm.views.fragments.Homegfragment
import androidx.fragment.app.Fragment
import com.example.mvvm.databinding.FragmentHomeBinding
import com.example.mvvm.R
import android.view.View
import androidx.navigation.fragment.navArgs
import android.view.LayoutInflater
import android.view.ViewGroup
import android.os.Bundle


class HomeFrag : Fragment(R.layout.fragment_home) {
    lateinit var binding: FragmentHomeBinding
   private val args:HomeFragArgs by navArgs()
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?) :View?{
        binding = FragmentHomeBinding.inflate(inflater,container, false)

        return binding.root
    }
    fun initViews(){
        binding.results.text = "Hi"
    }

}