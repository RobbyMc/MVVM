package com.example.mvvm.views.fragments.LoginFragment

 data class NumberListState (
     var isLoading : Boolean = false,
     var errorMsg: String = "An Error has occurred",
     var number: Int? = null
         )
