package com.example.mvvm.viewmodel

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.mvvm.repository.UserRepo
import com.example.mvvm.views.fragments.LoginFragment.NumberListState
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch


//import com.example.mvvm.views.fragments.LoginFragment

class UserViewModel : ViewModel() {
    val TAG = "UserViewModel"
    val randomRangeStart = 1
    val randomRangeEnd = 200
    val  numberList = (1..200).map{(randomRangeStart..randomRangeEnd).random()}
    private val repo: UserRepo = UserRepo.getInstance(1)
    private var number:MutableLiveData<NumberListState> = MutableLiveData(NumberListState())
    val numberListState: LiveData<NumberListState> get() = numberListState

    fun handleSelection(option:String){
        val number = when(option){
            "ODD Number" ->odd().random()
            "RANDOM Number" -> numberList.random()
            "EVEN Number" -> even().random()
            else -> throw error("ERROR OCCURRED")
        }
        viewModelScope.launch{
            with(numberListState){
                Log.e(TAG, "loading numbers....")

                 value?.copy(isLoading = true)
                delay(1000)
                 value?.copy(isLoading = false)
                 value?.copy(number = number)

            }
        }
    }

    fun even(): MutableList<Int> {
        val evenNumber: MutableList<Int> = mutableListOf()
        for(number in numberList){
            if(number % 2 ==0) evenNumber.add(number)
        }
        return evenNumber
    }
    fun odd(): MutableList<Int> {
        val oddNumber: MutableList<Int> = mutableListOf()
        for(number in numberList){
            if(number % 2!=0) oddNumber.add(number)
        }
        return oddNumber
    }


}