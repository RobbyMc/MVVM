package com.example.mvvm.views.fragments.LoginFragment
import android.graphics.Color
import com.example.mvvm.R
import android.os.Bundle
import com.example.mvvm.databinding.FragmentNumberlistBinding
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.example.mvvm.viewmodel.UserViewModel

class NumberListFragmentFragment : Fragment(R.layout.fragment_numberlist) {
    val TAG = "NumberListFragment"
    lateinit var binding: FragmentNumberlistBinding

    lateinit var loginState: NumberListState

    private val viewModel by viewModels<UserViewModel>()

    override fun onCreateView(inflater: LayoutInflater,
                              container: ViewGroup?,
                              savedInstanceState: Bundle?):View?{
        binding = FragmentNumberlistBinding.inflate(inflater,container, false)
        initViews()
        initObservers()
        return binding.root
    }
    private fun initViews(){
        with(binding){

            btnSubmit.setOnClickListener{

                val choice = btnSubmit.text.toString()
                viewModel.handleSelection(choice)

            }
        }
    }
    private fun initObservers(){

        with(binding){
            viewModel.numberListState.observe(viewLifecycleOwner){
                if(it.number !=null){
                    val number = it.number!!.toInt()
                    println(number)
                    val header: String="NumberList"
                    header.toString()

                }
            }
        }

    }


}