package com.example.mvvm.repository
import android.util.Log
class UserRepo  private constructor(
  numbers:Number
){
    val TAG = "UserRepo"
    val numberList = mutableListOf(numbers)

    fun addNumbers(numbers: Number){
        Log.e(TAG,"addNumbers: adding $numbers to number list")
        numberList.add(numbers)
        val randomRangeStart = 1
        val randomRangeEnd = 200
       val  numberList = (1..200).map{(randomRangeStart..randomRangeEnd).random()}
        for(i in randomRangeStart..randomRangeEnd) {
            println("Range $i-${i + 1}: ${numberList.filter{it >=i && it <= i+1}.count()}")
        }
    }

    companion object{
        private var instance: UserRepo?= null
        fun getInstance(theList:Number): UserRepo = UserRepo(theList)
    }


}