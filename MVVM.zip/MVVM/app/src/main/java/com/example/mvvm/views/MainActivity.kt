package com.example.mvvm.views
import androidx.appcompat.app.AppCompatActivity
import com.example.mvvm.R
import android.os.Bundle
class MainActivity: AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?){
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

}